import { Dashboard } from "@/components/component/dashboard";
import Image from "next/image";

export default function Home() {
  return (
    <Dashboard />
  );
}
